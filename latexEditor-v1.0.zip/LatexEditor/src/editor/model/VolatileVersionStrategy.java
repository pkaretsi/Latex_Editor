package editor.model;

import java.util.ArrayList;

public class VolatileVersionStrategy implements VersionStrategy {

	ArrayList<Document> entireHistory = new ArrayList <Document>();
	
	public VolatileVersionStrategy() {}
		
	public void putVersion(Document document) {
		entireHistory.add(document);
	}
	
	public Document getVersion() {
		return entireHistory.get(entireHistory.size()-1);
	}
	
	public ArrayList<Document> getEntireHistory() {
		return entireHistory;
	}

	public void setEntireHistory(ArrayList<Document> entireHistory) {
		this.entireHistory = entireHistory;
	}
	
	public void removeVersion() {
		entireHistory.remove(entireHistory.size()-1);
	}
	
}