package editor.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class StableVersionStrategy implements VersionStrategy {
	
	ArrayList<Document> entireHistory= new ArrayList <Document>();
	
	public StableVersionStrategy() {}
	
	public void putVersion(Document document) {
		entireHistory.add(document);
		String version=document.getVersionID();
		PrintWriter outputWriter = null;
		try {
			File fileOut = new File("document"+version+".tex");
			outputWriter = new PrintWriter(fileOut);
		}catch(FileNotFoundException e) {
			System.out.println("Error opening file");
			System.exit(0);
		}
		outputWriter.println(document.getContents());
		outputWriter.close();
	}
		
	public Document getVersion() {
		return entireHistory.get(entireHistory.size()-1);
	}
	
	public ArrayList<Document> getEntireHistory() {
		return entireHistory;
	}

	public void setEntireHistory(ArrayList<Document> entireHistory) {
		this.entireHistory = entireHistory;
	}
	
	public void removeVersion() {
		entireHistory.remove(entireHistory.size()-1);
	}
	

}
