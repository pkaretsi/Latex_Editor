package editor.controller;

public interface Command {
	
	public void execute();
}
