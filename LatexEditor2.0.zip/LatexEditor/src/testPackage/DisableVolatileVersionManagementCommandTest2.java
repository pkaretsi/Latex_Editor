package testPackage;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import editor.controller.Command;
import editor.controller.LatexEditorController;
import editor.model.Document;
import editor.model.VersionStrategy;

public class DisableVolatileVersionManagementCommandTest2 {

	@Test
	public void test() {
		ArrayList<Document> loaded = new ArrayList<Document>();
		Document newDoc;
		for(int i=0; i<5; i++){
			newDoc = new Document("me", "unknown", "2", "\\end{document} " + i, "article");
			loaded.add(newDoc);
		}
		newDoc = new Document("me", "unknown", "2", "Hello World", "article");
		LatexEditorController controller = new LatexEditorController();
		controller.setCurrentDocument(newDoc);
		controller.getVersionManager().setLoadedHistory(loaded);
		controller.getVersionManager().enable();
		VersionStrategy vs = controller.getVersionFactory().createStrategy("Volatile");
		controller.getVersionManager().setStrategy(vs);
		int size = controller.getVersionManager().getStrategy().getEntireHistory().size();
		Command command = controller.getCommandFactory().createCommands("DisableVersionsManagement", controller);
		controller.setGuiAction("DisableVersionsManagement");
		command.execute();
		Command editCommand = controller.getCommandFactory().createCommands("Edit", controller);
		String oldContents = controller.getCurrentDocument().getContents();
		controller.getCurrentDocument().setContents(oldContents + " Hellooo");
		controller.setGuiAction("Edit SaveVersion");
		editCommand.execute();

		assertEquals(controller.getVersionManager().getStrategy().getEntireHistory().size(), size);
		assertNotEquals(controller.getVersionManager().isEnabled(), true);
	}

}
