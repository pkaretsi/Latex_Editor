package testPackage;

import static org.junit.Assert.*;

import org.junit.Test;

import editor.controller.Command;
import editor.controller.LatexEditorController;
import editor.model.Document;
import editor.model.VersionStrategy;

public class CancelRollbackCommandTest2 {

	@Test
	public void test() {
		LatexEditorController controller = new LatexEditorController();
		Document newDoc = new Document("me", "unknown", "5", "Hello World this is my book", "book");
		controller.setCurrentDocument(newDoc);
		controller.getVersionManager().enable();
		VersionStrategy vs = controller.getVersionFactory().createStrategy("Volatile");
		controller.getVersionManager().setStrategy(vs);
		controller.setFirstDocument(newDoc.clone(newDoc));
		String oldContents = controller.getCurrentDocument().getContents();
		Command editCommand = controller.getCommandFactory().createCommands("Edit", controller);
		String text = oldContents + " Hellooo World";
		controller.getCurrentDocument().setContents(text);
		controller.setGuiAction("Edit SaveVersion");
		editCommand.execute();
		Command rollBack = controller.getCommandFactory().createCommands("Rollback", controller);
		controller.setGuiAction("Rollback");
		rollBack.execute();
		rollBack = controller.getCommandFactory().createCommands("CancelRollback", controller);
		controller.setGuiAction("CancelRollback");
		rollBack.execute();
		assertNotEquals(controller.getCurrentDocument().getContents(), oldContents);
	}

}
