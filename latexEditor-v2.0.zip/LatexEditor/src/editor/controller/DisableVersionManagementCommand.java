/*This class is executed when version tracking 
 * mechanism is going to be disabled. 
 */

package editor.controller;


public class DisableVersionManagementCommand implements Command {

	private LatexEditorController controller;

	public DisableVersionManagementCommand(LatexEditorController controller){
		this.controller = controller;
	}
	
	@Override
	public void execute() {
		controller.getVersionManager().disable();
		controller.setStringReturned(controller.getCurrentDocument().getContents());
	}

}
