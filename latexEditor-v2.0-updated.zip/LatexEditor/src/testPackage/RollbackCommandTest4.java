/*This test initializes the basic components
 * needed to do a rollback to a previous 
 * version. Then, an editCommand saves
 * a new version and compare the contents
 * after executing rollback command.
 */

package testPackage;

import static org.junit.Assert.*;

import org.junit.Test;

import editor.controller.Command;
import editor.controller.LatexEditorController;
import editor.model.Document;
import editor.model.VersionStrategy;

public class RollbackCommandTest4 {

	@Test
	public void test() {
		LatexEditorController controller = new LatexEditorController();
		Document newDoc = new Document("me", "unknown", "1", "\\end{document}", "book");
		controller.setCurrentDocument(newDoc);
		controller.getVersionManager().enable();
		VersionStrategy vs = controller.getVersionFactory().createStrategy("Stable");
		controller.getVersionManager().setStrategy(vs);
		vs = controller.getVersionManager().getStrategy();
		controller.setFirstDocument(newDoc.clone(newDoc));
		String oldContents = controller.getCurrentDocument().getContents();
		
		Command editCommand = controller.getCommandFactory().createCommands("Edit", controller);
		String text = oldContents + " Hellooo World Stable ";
		controller.getCurrentDocument().setContents(text);
		controller.setGuiAction("Edit SaveVersion");
		editCommand.execute();
		Command rollBack = controller.getCommandFactory().createCommands("Rollback", controller);
		controller.setGuiAction("Rollback");
		rollBack.execute();
		assertEquals(controller.getCurrentDocument().getContents(), oldContents);
	}

}
