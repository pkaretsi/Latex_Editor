/*This test initializes the basic components
 * needed to do a rollback to a previous 
 * version. Then, by using an editCommand, we save
 * some new versions and compare the contents
 * after executing rollback command.
 */ 

package testPackage;

import static org.junit.Assert.*;

import org.junit.Test;

import editor.controller.Command;
import editor.controller.LatexEditorController;
import editor.model.Document;
import editor.model.VersionStrategy;

public class RollbackCommandTest5 {

	@Test
	public void test() {
		LatexEditorController controller = new LatexEditorController();
		Document newDoc = new Document("me", "unknown", "2", "\\end{document}", "book");
		controller.setCurrentDocument(newDoc);
		controller.getVersionManager().enable();
		VersionStrategy vs = controller.getVersionFactory().createStrategy("Volatile");
		controller.getVersionManager().setStrategy(vs);
		vs = controller.getVersionManager().getStrategy();
		String oldContents = controller.getCurrentDocument().getContents();
		
		Command editCommand = controller.getCommandFactory().createCommands("Edit", controller);
		String text = oldContents + " Hellooo World";
		controller.getCurrentDocument().setContents(text);
		controller.setGuiAction("Edit SaveVersion");
		editCommand.execute();
		text = text + " second version";
		controller.getCurrentDocument().setContents(text);
		editCommand.execute();
		oldContents = controller.getCurrentDocument().getContents();
		Command rollBack = controller.getCommandFactory().createCommands("Rollback", controller);
		controller.setGuiAction("Rollback");
		rollBack.execute();
		assertNotEquals(controller.getCurrentDocument().getContents(), oldContents);
	}

}
