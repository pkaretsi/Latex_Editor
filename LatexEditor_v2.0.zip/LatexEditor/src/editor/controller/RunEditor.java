/*This file contains main function. 
 * 
 */
package editor.controller;

import window.view.EditorView;

public class RunEditor {

	public static void main(String[] args) {
		EditorView display = new EditorView();
		LatexEditorController controller = new LatexEditorController();
	}

}