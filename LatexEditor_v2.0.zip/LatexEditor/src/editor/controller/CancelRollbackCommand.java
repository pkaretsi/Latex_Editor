/*This class implements the reverse operation of rollback.
 * If a rollback operation has occurred before, it restores
 * the last "cancelled" version, otherwise sets proper warning message
 * for display. 
 */

package editor.controller;

public class CancelRollbackCommand implements Command {

	private LatexEditorController controller;
	
	public CancelRollbackCommand(LatexEditorController controller){
		this.controller = controller;
	}
	
	@Override
	public void execute() {
		if(controller.getVersionManager().getRollbackToNext() == null){
			controller.setStringReturned("Cancellation is not available.");
			return;
		}
		controller.getVersionManager().rollbackToNextVersion();
		controller.setCurrentDocument(controller.getVersionManager().getCurrentVersion());
		//System.out.println("@@@\n" + controller.getCurrentDocument().getContents());
		controller.setStringReturned(controller.getCurrentDocument().getContents());
	}

}
